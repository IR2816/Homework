package controllers

import (
    "encoding/json"
    "net/http"
    "api/models"
    "api/config"
    "log"
)

func GetStudents(w http.ResponseWriter, r *http.Request) {
    db := config.ConnectDB()
    defer db.Close()

    // Query untuk mengambil semua data students
    rows, err := db.Query("SELECT id_students, nis, name, gender FROM students")
    
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    // Slice untuk menampung hasil
    var students []models.Student

    // Iterasi hasil query
    for rows.Next() {
        var student models.Student
        err := rows.Scan(&student.ID, &student.NIS, &student.Name, &student.Gender)
        if err != nil {
            http.Error(w, err.Error(), http.StatusInternalServerError)
            return
        }
        students = append(students, student)
    }

    // Set header response sebagai JSON
    w.Header().Set("Content-Type", "application/json")
    
    // Kirim response JSON
    json.NewEncoder(w).Encode(students)
}

func PostStudent(w http.ResponseWriter, r *http.Request) {
    var student models.Student
    err := json.NewDecoder(r.Body).Decode(&student)
    if err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    db := config.ConnectDB()
    defer db.Close()

    _, err = db.Exec("INSERT INTO students (nis, name, gender) VALUES (?, ?, ?)", student.NIS, student.Name, student.Gender)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(student)
}

func PutStudent(w http.ResponseWriter, r *http.Request) {
    id := r.URL.Path[len("/api/students/"):]

    var student models.Student
    err := json.NewDecoder(r.Body).Decode(&student)
    if err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    db := config.ConnectDB()
    defer db.Close()

    result, err := db.Exec("UPDATE students SET nis=?, name=?, gender=? WHERE id_students=?", student.NIS, student.Name, student.Gender, id)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    rowsAffected, err := result.RowsAffected()
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    log.Printf("Updating student ID: %s, Rows affected: %d", id, rowsAffected)

    if rowsAffected == 0 {
        http.Error(w, "No student found with the given ID", http.StatusNotFound)
        return
    }

    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(student)
}

func DeleteStudent(w http.ResponseWriter, r *http.Request) {
    id := r.URL.Path[len("/api/students/"):]

    db := config.ConnectDB()
    defer db.Close()

    result, err := db.Exec("DELETE FROM students WHERE id_students=?", id)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    rowsAffected, err := result.RowsAffected()
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    log.Printf("Deleting student ID: %s, Rows affected: %d", id, rowsAffected)

    if rowsAffected == 0 {
        http.Error(w, "No student found with the given ID", http.StatusNotFound)
        return
    }

    w.WriteHeader(http.StatusNoContent)
}
