package routes

import (
	"api/controllers"
	"net/http"
	"strings"
)

func studentHandler(w http.ResponseWriter, r *http.Request) {
	pathParts := strings.Split(r.URL.Path, "/")

	if len(pathParts) < 4 { // Expected format: /api/students/{id}
		http.Error(w, "Invalid request URL", http.StatusBadRequest)
		return
	}

	id := pathParts[3] // Extracting ID from URL

	switch r.Method {
	case http.MethodPut:
		r.URL.Path = "/api/students/" + id // Set the path for the controller to use
		controllers.PutStudent(w, r)

	case http.MethodDelete:
		r.URL.Path = "/api/students/" + id // Set the path for the controller to use
		controllers.DeleteStudent(w, r)

	default:
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

func SetupStudentRoutes() {
	http.HandleFunc("/api/students", controllers.GetStudents)        // GET
	http.HandleFunc("/api/students/create", controllers.PostStudent) // POST
	http.HandleFunc("/api/students/{id}", studentHandler)            // PUT & DELETE with ID

}
